from django.contrib import admin
from .models import *
# Register your models here.

admin.site.register(Admin_Helath_CSV)
admin.site.register(Doctor)
admin.site.register(Patient)
admin.site.register(Feedback)
admin.site.register(Search_Data)
